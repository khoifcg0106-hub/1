JARVIS-1 - Bộ file kiểm thử Document Intelligence (Bước 3)

FILE CHÍNH
1. JARVIS_Test_PDF_A.pdf
2. JARVIS_Test_PDF_B.pdf
   -> Dùng cho test đọc PDF và so sánh 2 PDF.
3. JARVIS_Test_DOCX_Ke_Hoach.docx
   -> Dùng cho test đọc, hiểu, tìm kiếm và trả lời câu hỏi.
4. JARVIS_Test_XLSX_Doanh_Thu.xlsx
   -> Dùng cho test đọc sheet và phân tích dữ liệu.

FILE PHỤ
5. JARVIS_Test_Data.csv
   -> Dùng thêm để test CSV/batch nếu cần.

KỊCH BẢN TEST
A. Kéo PDF_A vào JARVIS:
   "Đọc file này và tóm tắt cho tôi."

B. Kéo PDF_A + PDF_B:
   "So sánh hai tài liệu này, nêu các điểm khác nhau về ngày, ngân sách,
   trạng thái và tiến độ."

C. Kéo DOCX:
   "Đọc tài liệu này và cho tôi biết: mục tiêu dự án, các mốc chính,
   các quy tắc dữ liệu và trả lời các câu hỏi ở mục 4."

D. Kéo XLSX:
   "Phân tích bảng này. Cho tôi tổng doanh thu, tổng chi phí,
   tổng lợi nhuận, tổng số đơn và tháng có doanh thu cao nhất."

E. Kéo DOCX + XLSX + PDF_A:
   "Dựa trên các tài liệu này, tạo cho tôi một báo cáo Word.
   Sau khi tạo xong hãy mở lại và kiểm tra file."

F. Test lỗi:
   "Hãy đọc file KHONG_TON_TAI_12345.docx và báo lỗi rõ ràng,
   không được làm JARVIS crash."

DỮ LIỆU LÀ GIẢ LẬP, CHỈ PHỤC VỤ KIỂM THỬ PHẦN MỀM.
